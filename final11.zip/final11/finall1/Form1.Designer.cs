﻿namespace finall1
{
    partial class Form1
    {
        /// <summary>
        ///Gerekli tasarımcı değişkeni.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///Kullanılan tüm kaynakları temizleyin.
        /// </summary>
        ///<param name="disposing">yönetilen kaynaklar dispose edilmeliyse doğru; aksi halde yanlış.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer üretilen kod

        /// <summary>
        /// Tasarımcı desteği için gerekli metot - bu metodun 
        ///içeriğini kod düzenleyici ile değiştirmeyin.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.madi = new System.Windows.Forms.TextBox();
            this.cmeydanca = new System.Windows.Forms.ComboBox();
            this.cotaq = new System.Windows.Forms.ComboBox();
            this.mnomresi = new System.Windows.Forms.NumericUpDown();
            this.cqiymet = new System.Windows.Forms.NumericUpDown();
            this.cnefer = new System.Windows.Forms.NumericUpDown();
            this.tarix1 = new System.Windows.Forms.DateTimePicker();
            this.cgrid = new System.Windows.Forms.DataGridView();
            this.btnrezerv = new System.Windows.Forms.Button();
            this.btndelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.mnomresi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cqiymet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnefer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cgrid)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(-1, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "MUSTERIADI";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(-1, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "MUSTERINOMRESI";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(176, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "MEYDANCA";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(160, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "OTAQLAR";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(338, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "QIYMETLER";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(338, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 17);
            this.label6.TabIndex = 5;
            this.label6.Text = "NECENEFER";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(503, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "TARIX";
            // 
            // madi
            // 
            this.madi.Location = new System.Drawing.Point(2, 26);
            this.madi.Name = "madi";
            this.madi.Size = new System.Drawing.Size(100, 20);
            this.madi.TabIndex = 7;
            // 
            // cmeydanca
            // 
            this.cmeydanca.FormattingEnabled = true;
            this.cmeydanca.Location = new System.Drawing.Point(163, 29);
            this.cmeydanca.Name = "cmeydanca";
            this.cmeydanca.Size = new System.Drawing.Size(121, 21);
            this.cmeydanca.TabIndex = 8;
            // 
            // cotaq
            // 
            this.cotaq.FormattingEnabled = true;
            this.cotaq.Location = new System.Drawing.Point(163, 91);
            this.cotaq.Name = "cotaq";
            this.cotaq.Size = new System.Drawing.Size(121, 21);
            this.cotaq.TabIndex = 9;
            // 
            // mnomresi
            // 
            this.mnomresi.Location = new System.Drawing.Point(2, 92);
            this.mnomresi.Maximum = new decimal(new int[] {
            1316134912,
            2328,
            0,
            0});
            this.mnomresi.Name = "mnomresi";
            this.mnomresi.Size = new System.Drawing.Size(120, 20);
            this.mnomresi.TabIndex = 10;
            // 
            // cqiymet
            // 
            this.cqiymet.Location = new System.Drawing.Point(341, 30);
            this.cqiymet.Maximum = new decimal(new int[] {
            -1593835520,
            466537709,
            54210,
            0});
            this.cqiymet.Name = "cqiymet";
            this.cqiymet.Size = new System.Drawing.Size(120, 20);
            this.cqiymet.TabIndex = 11;
            // 
            // cnefer
            // 
            this.cnefer.Location = new System.Drawing.Point(341, 92);
            this.cnefer.Maximum = new decimal(new int[] {
            -1304428544,
            434162106,
            542,
            0});
            this.cnefer.Name = "cnefer";
            this.cnefer.Size = new System.Drawing.Size(120, 20);
            this.cnefer.TabIndex = 13;
            // 
            // tarix1
            // 
            this.tarix1.Location = new System.Drawing.Point(506, 30);
            this.tarix1.Name = "tarix1";
            this.tarix1.Size = new System.Drawing.Size(200, 20);
            this.tarix1.TabIndex = 14;
            // 
            // cgrid
            // 
            this.cgrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.cgrid.Location = new System.Drawing.Point(12, 235);
            this.cgrid.Name = "cgrid";
            this.cgrid.Size = new System.Drawing.Size(776, 203);
            this.cgrid.TabIndex = 15;
            this.cgrid.RowHeaderMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.cgrid_RowHeaderMouseDoubleClick);
            // 
            // btnrezerv
            // 
            this.btnrezerv.Location = new System.Drawing.Point(526, 89);
            this.btnrezerv.Name = "btnrezerv";
            this.btnrezerv.Size = new System.Drawing.Size(143, 23);
            this.btnrezerv.TabIndex = 16;
            this.btnrezerv.Text = "REZERV ET";
            this.btnrezerv.UseVisualStyleBackColor = true;
            this.btnrezerv.Click += new System.EventHandler(this.btnrezerv_Click);
            // 
            // btndelete
            // 
            this.btndelete.Location = new System.Drawing.Point(318, 169);
            this.btndelete.Name = "btndelete";
            this.btndelete.Size = new System.Drawing.Size(143, 23);
            this.btndelete.TabIndex = 17;
            this.btndelete.Text = "DELETE";
            this.btndelete.UseVisualStyleBackColor = true;
            this.btndelete.Click += new System.EventHandler(this.btndelete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btndelete);
            this.Controls.Add(this.btnrezerv);
            this.Controls.Add(this.cgrid);
            this.Controls.Add(this.tarix1);
            this.Controls.Add(this.cnefer);
            this.Controls.Add(this.cqiymet);
            this.Controls.Add(this.mnomresi);
            this.Controls.Add(this.cotaq);
            this.Controls.Add(this.cmeydanca);
            this.Controls.Add(this.madi);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.mnomresi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cqiymet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cnefer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cgrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox madi;
        private System.Windows.Forms.ComboBox cmeydanca;
        private System.Windows.Forms.ComboBox cotaq;
        private System.Windows.Forms.NumericUpDown mnomresi;
        private System.Windows.Forms.NumericUpDown cqiymet;
        private System.Windows.Forms.NumericUpDown cnefer;
        private System.Windows.Forms.DateTimePicker tarix1;
        private System.Windows.Forms.DataGridView cgrid;
        private System.Windows.Forms.Button btnrezerv;
        private System.Windows.Forms.Button btndelete;
    }
}

