﻿using finall1.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace finall1
{
    public partial class Form1 : Form
    {

        Entities db = new Entities();
        Umumi11 umumi11;


        public void fillmey3()
        {
            cmeydanca.Items.AddRange(db.Meydancas.Select(x => x.Name).ToArray());
        }



        public void fillotaq3()
        {
            cotaq.Items.AddRange(db.Otaqlars.Select(x => x.Name).ToArray());
        }

        public void filldatagrid3()
        {
            cgrid.DataSource = db.Umumi11.Where(x => !x.IsActive).Select(x => new
            {
                x.ID,
                Meydanca = x.Meydanca.Name,
                Otaqlar = x.Otaqlar.Name,

                MusteriAdi = x.MusteriAdi,
                x.MusteriNomresi,
                x.Qiymetler,
                x.NeceNefer,
                x.Tarix

            }).ToList();
        }


        public Form1()
        {
            InitializeComponent();
        }

      

        private void Form1_Load(object sender, EventArgs e)
        {
            fillmey3();
            fillotaq3();
            filldatagrid3();
        }
        private void btnrezerv_Click(object sender, EventArgs e)
        {
            Umumi11 mln2 = new Umumi11();
            mln2.MeydancaID = 1;
            mln2.OtaqID = 1;
            mln2.MusteriAdi = madi.Text;
            mln2.MusteriNomresi = Convert.ToInt32(mnomresi.Value);

            mln2.Qiymetler = Convert.ToInt32(cqiymet.Value);
            mln2.NeceNefer = Convert.ToInt32(cnefer.Value);
            mln2.Tarix = tarix1.Value;
            db.Umumi11.Add(mln2);
            db.SaveChanges();
            MessageBox.Show("rezerv olundu");
            filldatagrid3();
        }

        private void cgrid_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            int mln2 = (int)cgrid.Rows[e.RowIndex].Cells[0].Value;
            umumi11 = db.Umumi11.Find(mln2);
            madi.Text = umumi11.MusteriAdi;
            mnomresi.Value = umumi11.MusteriNomresi;
            cmeydanca.Text = umumi11.Meydanca.Name;
            cotaq.Text = umumi11.Otaqlar.Name;
            cqiymet.Value = umumi11.Qiymetler;
            cnefer.Value = umumi11.NeceNefer;
            tarix1.Value = umumi11.Tarix;
        }

        private void btndelete_Click(object sender, EventArgs e)
        {

            umumi11.IsActive = true;
            db.SaveChanges();
            filldatagrid3();
        }
    }
}
